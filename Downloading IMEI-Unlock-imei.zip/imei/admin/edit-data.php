<?php
include_once 'dbconfig.php';
include_once 'header.php';
include_once("class.crud.php");
	
if(isset($_POST['btn-update']))
{
	$order_no = $_POST['order_no'];
	$date_time = $_POST['date_time'];
	$imei = $_POST['imei'];
	$premium = $_POST['premium'];
	$transection_id = $_POST['transection_id'];
	$status = $_POST['status'];
	$comment = $_POST['comment'];
	
	if($crud->update($order_no,$date_time,$imei,$premium,$transection_id,$status,$comment))
	{
		$msg = "<div class='alert alert-info'>
				<strong>WOW!</strong> Record was updated successfully <a href='index.php'>HOME</a>!
				</div>";
	}
	else
	{
		$msg = "<div class='alert alert-warning'>
				<strong>SORRY!</strong> ERROR while updating record !
				</div>";
	}
}

if(isset($_REQUEST['edit_id']))
{   
	$order_no = $_REQUEST['edit_id'];
	extract($crud->getID($order_no));	
}

?>
<?php include_once 'header.php'; ?>

<div class="clearfix"></div>
<div class="container">

<?php

if(isset($msg))
{ 	echo $msg;  }

?>


</div>

<div class="clearfix"></div><br />

<div class="container">
	 
     <form method='post'>
 
    <table class='table table-bordered'>
            <input type="hidden" name="order_no" id="order_no" value="<?php echo $order_no; ?>">
        <tr><td>Date and Time </td>
            <td><input type='text' name='date_time' class='form-control' value="<?php echo $date_time; ?>" required> 
 		</td></tr>
 
        <tr><td>IMEI</td>
            <td><input type='text' name='imei' class='form-control' value="<?php echo $imei; ?>" required></td>
        </tr>
 
        <tr><td>Premium</td>
            <td><!--<input type='text' name='premium' class='form-control' value="<?php echo $premium; ?>" required>-->
			      <label class="radio-inline"><input name='premium' id='premium' type="radio" value="y" <?php if($premium =='y'){ echo 'checked=checked'; } ?> >YES</label>
                  <label class="radio-inline"><input name='premium' id='premium' type="radio" value="n" <?php if($premium =='n'){ echo 'checked=checked'; } ?> >NO</label>
            </td>
        </tr>
 
        <tr><td>Transection Id</td>
            <td><input type='text' name='transection_id' class='form-control' value="<?php echo $transection_id; ?>" required>
			   </td>
        </tr>
		
		<tr>
            <td>Status</td>
            <td><!--<input type='text' name='status' class='form-control' value="<?php echo $status; ?>" required>-->
				<select class="form-control" id="status" name='status'>
				<option value="n" <?php if($status=='n'){echo 'selected=selected'; } ?>>NEW</option>
				<option value="p" <?php if($status=='p'){echo 'selected=selected'; } ?>>PROCESSING</option>
				<option value="c" <?php if($status=='c'){echo 'selected=selected'; } ?>>COMPLETE</option>
				<option value="d" <?php if($status=='d'){echo 'selected=selected'; } ?>>DENIED</option>
				</select>
			</td>
        </tr>
		
		<tr>
            <td>Comments</td>
            <td><textarea id="comment" name="comment"> <?php echo $comment ; ?></textarea></td>
        </tr>
 
        <tr>
            <td colspan="2">
                <button type="submit" class="btn btn-primary" name="btn-update">
    			<span class="glyphicon glyphicon-edit"></span>  Update this Record
				</button>
                <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; CANCEL</a>
            </td>
        </tr>
 
    </table>
</form>
     
     
</div>


<?php include_once 'footer.php'; ?>