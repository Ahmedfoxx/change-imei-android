<?php

require_once('admin/dbconfig1.php');

class crud
{
	private $db;
	
	function __construct($DB_con)
	{
		$this->db = $DB_con;
	}
	
	
	public function create($date_time,$imei,$premium,$transection_id,$status)
	{    echo $date_time;  echo '<br>'; echo $imei; echo '<br>';  echo $premium;  echo '<br>'; echo $transection_id ; echo '<br>';  echo $status; 
		try
		{
			$stmt = $this->db->prepare("INSERT INTO imei(date_time,imei,premium,transection_id,status) VALUES( :date_time, :imei, :premium,:transection_id,:status)");
			//$stmt->bindparam(":order_no",$order_no);
			$stmt->bindparam(":date_time",$date_time);
			$stmt->bindparam(":imei",$imei);
			$stmt->bindparam(":premium",$premium);
			$stmt->bindparam(":transection_id",$transection_id);
			$stmt->bindparam(":status",$status);
			$stmt->execute();
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}
	
	
	
}
