<?php

	require_once("session.php");
	
		
	$user_id = $_SESSION['user_session'];
	
	$stmt = $auth_user->runQuery("SELECT * FROM users WHERE user_id=:user_id");
	$stmt->execute(array(":user_id"=>$user_id));
	
	$userRow=$stmt->fetch(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen">
<!--<script type="text/javascript" src="jquery-1.11.3-jquery.min.js"></script>
--><link rel="stylesheet" href="style.css" type="text/css"  />
<title>welcome - <?php print($userRow['user_email']); ?></title>
</head>
<body>

<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
         </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Home</a></li>
            </ul>
          <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['user_email']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="profile.php"><span class="glyphicon glyphicon-user"></span>&nbsp;View Profile</a></li>
                <li><a href="logout.php?logout=true"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>


    <div class="clearfix"></div>
    	
    
<div class="container-fluid" style="margin-top:80px;">
	
    <div class="container">
    
    	<label class="h5">welcome : <?php print($userRow['user_name']); ?></label>
        <hr />
        
        <h1>
        <a href="home.php"><span class="glyphicon glyphicon-home"></span> home</a> &nbsp; 
        <a href="profile.php"><span class="glyphicon glyphicon-user"></span> profile</a></h1>
       	<hr/>
      
        </div>
	</div>

<div class="container">
     <form name="status_form" id="status_form" action=""><table style="float:right; width:40%;" >
	   <tr> <td><input type='text' name='imei'  class='form-control' value="<?php if( isset($_REQUEST['imei']) ){ echo $_REQUEST['imei']; } ?>" required placeholder="IMEI"></td><td></td>
            <td>&nbsp;&nbsp;</td>
            <td>
				<select class="form-control" id="status" name='status' onchange="this.form.submit()" >
				<option value="al" <?php if(isset($_REQUEST['status']) and ($_REQUEST['status'] =='al')){echo 'selected=selected'; } ?> >Status </option>
				<option value="n" <?php if(isset($_REQUEST['status']) and ($_REQUEST['status']=='n')){echo 'selected=selected'; } ?> >NEW</option>
				<option value="p" <?php if(isset($_REQUEST['status']) and ($_REQUEST['status']=='p')){echo 'selected=selected'; } ?>>PROCESSING</option>
				<option value="c" <?php if(isset($_REQUEST['status']) and ($_REQUEST['status']=='c')){echo 'selected=selected'; } ?>>COMPLETE</option>
				<option value="d" <?php if(isset($_REQUEST['status']) and ($_REQUEST['status']=='d')){echo 'selected=selected'; } ?>>DENIED</option>
				</select>
				
			</td>
			<td>&nbsp;&nbsp; <input type="submit" name="search" id="search" value="GO"  > </td>
        </tr></table>
		</form>
		</br><br/>
		
	 <table class='table table-bordered table-responsive'>
     <tr>
     <th>Order Number</th>
     <th>Date Time</th>
     <th>Imei</th>
     <th>Premium</th>
     <th>Transection_id</th>
	 <th>Status</th>
     <th colspan="2" align="center">Actions</th>
     </tr>
     <?php
	 
	 //  print_r($_REQUEST);
	  // $where='';
	  $status ='';
	  $imei = '';
	   
	   if(isset($_REQUEST['imei']) and !empty($_REQUEST['imei']) )
	   {
	     $query = "SELECT * FROM imei where imei = (:imei)";       
		 $imei = $_REQUEST['imei'];
	   }elseif(!isset($_REQUEST['status']))
	   {
    	$query = "SELECT * FROM imei order by order_no desc "; 
	   }elseif($_REQUEST['status']!='al') {
	     $query = "SELECT * FROM imei where status IN (:status) order by order_no desc ";       
		 $status = $_REQUEST['status'] ;
	   }elseif(isset($_REQUEST['status']) and ($_REQUEST['status']=='al'))
	   { $query = "SELECT * FROM imei  order by order_no desc "; 
	   }
	      
		  
	   	$records_per_page=10;
		$newquery = $crud->paging($query,$records_per_page);
		$crud->dataview($newquery,$status,$imei);
		
	 ?>
    <tr>
        <td colspan="8" align="center">
 			<div class="pagination-wrap">
            <?php $crud->paginglink($query,$records_per_page,$status,$imei); ?>
        	</div>
        </td>
    </tr> 
</table>         
</div>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>