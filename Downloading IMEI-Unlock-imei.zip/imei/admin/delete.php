<?php
include_once 'dbconfig.php';
require_once("class.crud.php");

if(isset($_POST['btn-del']))
{
	$id = $_REQUEST['delete_id'];
	$crud->delete($id);
	header("Location: delete.php?deleted");	
}

?>

<?php include_once 'header.php'; ?>

<div class="clearfix"></div>

<div class="container">

	<?php
	if(isset($_POST['deleted']))
	{
		?>
        <div class="alert alert-success">
    	<strong>Success!</strong> record was deleted... 
		</div>
        <?php
	}
	else
	{
		?>
        <div class="alert alert-danger">
    	<strong>Sure !</strong> to remove the following record ? 
		</div>
        <?php
	}
	?>	
</div>

<div class="clearfix"></div>

<div class="container">
 	
	 <?php
	 //print_r($_REQUEST);
	 if(isset($_REQUEST['delete_id']))
	 {
		 ?>
         <table class='table table-bordered'>
         <tr>
         <th>#</th>
         <th>Date Time</th>
         <th>Imei</th>
         <th>Premium</th>
         <th>Transection_id</th>
		 <th>Status</th>
         </tr>
         <?php
		 
		if(isset($_REQUEST['delete_id']))
		{   
		$order_no = $_REQUEST['delete_id'];
		extract($crud->getID($order_no));	
		}
		// extract($crud->getID($order_no));	 
		 
       //  $stmt = $crud->prepare("SELECT * FROM imei WHERE order_no=:order_no");
       //  $stmt->execute(array(":order_no"=>$_REQUEST['delete_id']));
       //  while($row=$stmt->fetch(PDO::FETCH_BOTH))
       //  {
             ?>
             <tr>
             <td><?php print($order_no); ?></td>
             <td><?php print($date_time); ?></td>
             <td><?php print($imei); ?></td>
             <td><?php print($premium); ?></td>
         	 <td><?php print($transection_id); ?></td>
			 <td><?php print($status); ?></td>
             </tr>
             <?php
         // }
         ?>
         </table>
         <?php
	 }
	 ?>
</div>

<div class="container">
<p>
<?php
if(isset($_REQUEST['delete_id']))
{
	?>
  	<form method="post">
    <input type="hidden" name="order_no" value="<?php echo $row['order_no']; ?>" />
    <button class="btn btn-large btn-primary" type="submit" name="btn-del"><i class="glyphicon glyphicon-trash"></i> &nbsp; YES</button>
    <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; NO</a>
    </form>  
	<?php
}
else
{
	?>
    <a href="index.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; Back to index</a>
    <?php
}
?>
</p>
</div>	
<?php include_once 'footer.php'; ?>